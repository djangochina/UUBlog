
$(document).ready(function() {
    $(".navs_0 > li").hover(
        function () {
            $(this)
        },
        function() {
        })
});